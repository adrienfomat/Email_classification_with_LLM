"""Run the same evaluation for several models and print a summary."""
import json

from emailclf import ClassificationTask, LLMSettings, evaluate
from emailclf.evaluate import load_dataset

task = ClassificationTask.from_yaml("configs/access_requests.yaml")
dataset = load_dataset("data/test_set_sample.jsonl")
models = ["phi4-mini", "ministral-3:8b", "qwen3.5:9b"]

for name in models:
    report = evaluate(task, LLMSettings(model=name), dataset)
    print(f"\n=== {name} ===")
    print(report["report_text"])
    print("field accuracy:", report["field_accuracy"])
    print(f"valid: {report['valid_rate']:.0%}  mean time: {report['mean_duration_ms']:.0f} ms")
    with open(f"results_{name.replace(':', '_')}.json", "w", encoding="utf-8") as f:
        json.dump(report, f, ensure_ascii=False, indent=2)
