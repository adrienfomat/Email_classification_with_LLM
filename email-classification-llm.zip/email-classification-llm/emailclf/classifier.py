import time

from ollama import Client
from pydantic import ValidationError

from .models import ClassificationResult, Email, LLMSettings
from .prompt import build_messages
from .task import ClassificationTask


def classify_email(email: Email, task: ClassificationTask, llm: LLMSettings,
                   client=None) -> ClassificationResult:
    """Classify one email and extract the fields of its label.
    `client` can be replaced by a fake object in tests (it only needs a .chat() method)."""
    client = client or Client(host=llm.host, timeout=llm.timeout_s)
    output_model = task.output_model()
    messages = build_messages(email, task)
    start = time.perf_counter()
    error = None

    for attempt in range(1, llm.max_retries + 2):
        try:
            response = client.chat(
                model=llm.model,
                messages=messages,
                format=output_model.model_json_schema(),   # constrained decoding
                options={"temperature": llm.temperature},
                think=llm.think,
            )
            parsed = output_model.model_validate_json(response.message.content)
            allowed = {f.name for f in task.fields_of(parsed.label)}
            fields = {k: v for k, v in parsed.fields.model_dump().items() if k in allowed}
            return ClassificationResult(
                label=parsed.label, fields=fields, is_valid=True, model=llm.model,
                duration_ms=int((time.perf_counter() - start) * 1000), attempts=attempt)
        except (ValidationError, ValueError) as exc:     # invalid JSON or value outside the schema
            error = f"{type(exc).__name__}: {exc}"

    return ClassificationResult(
        label=task.fallback_label, fields={}, is_valid=False, model=llm.model,
        duration_ms=int((time.perf_counter() - start) * 1000), attempts=llm.max_retries + 1, error=error)
