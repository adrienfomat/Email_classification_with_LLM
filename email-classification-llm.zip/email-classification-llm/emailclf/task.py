from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Literal, Optional

import yaml
from pydantic import BaseModel, create_model

TYPE_MAP = {"string": str, "number": float, "date": str, "list[string]": list[str]}


@dataclass
class FieldSpec:
    name: str
    type: str
    description: str = ""
    values: list[str] | None = None             # only for type "enum"

    def python_type(self):
        if self.type == "enum":
            return Literal[tuple(self.values)]
        if self.type not in TYPE_MAP:
            raise ValueError(f"Unknown field type: {self.type}")
        return TYPE_MAP[self.type]


@dataclass
class LabelSpec:
    name: str
    description: str
    fields: list[FieldSpec] = field(default_factory=list)


@dataclass
class Example:
    subject: str
    body: str
    label: str
    fields: dict[str, Any] = field(default_factory=dict)
    attachment_names: list[str] = field(default_factory=list)


@dataclass
class ClassificationTask:
    """Project-specific configuration: everything that changes from one project to another."""
    name: str
    context: str
    labels: list[LabelSpec]
    fallback_label: str
    examples: list[Example] = field(default_factory=list)

    @classmethod
    def from_yaml(cls, path: str | Path) -> "ClassificationTask":
        raw = yaml.safe_load(Path(path).read_text(encoding="utf-8"))
        labels = []
        for name, spec in raw["labels"].items():
            fields = [FieldSpec(name=f, **fs) for f, fs in (spec.get("fields") or {}).items()]
            labels.append(LabelSpec(name=name, description=spec["description"].strip(), fields=fields))
        examples = [Example(**e) for e in raw.get("examples", [])]
        task = cls(name=raw["name"], context=raw["context"].strip(), labels=labels,
                   fallback_label=raw["fallback_label"], examples=examples)
        task.check()
        return task

    def check(self) -> None:
        names = [l.name for l in self.labels]
        if self.fallback_label not in names:
            raise ValueError(f"fallback_label '{self.fallback_label}' is not one of the labels {names}")
        for ex in self.examples:
            if ex.label not in names:
                raise ValueError(f"Example label '{ex.label}' is not one of the labels {names}")

    @property
    def label_names(self) -> list[str]:
        return [l.name for l in self.labels]

    def fields_of(self, label: str) -> list[FieldSpec]:
        return next(l.fields for l in self.labels if l.name == label)

    def output_model(self) -> type[BaseModel]:
        """Pydantic model used both as JSON schema for the LLM and to validate its answer.
        Every field of every label is optional; only the fields of the chosen label are kept afterwards."""
        all_fields: dict[str, FieldSpec] = {}
        for l in self.labels:
            for f in l.fields:
                all_fields.setdefault(f.name, f)
        fields_model = create_model(
            "ExtractedFields",
            **{f.name: (Optional[f.python_type()], None) for f in all_fields.values()},
        )
        return create_model(
            "ClassifierOutput",
            label=(Literal[tuple(self.label_names)], ...),
            fields=(fields_model, ...),
        )
