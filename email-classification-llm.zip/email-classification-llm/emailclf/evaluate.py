import json
from pathlib import Path

from sklearn.metrics import classification_report, confusion_matrix

from .classifier import classify_email
from .models import Email, LLMSettings
from .task import ClassificationTask


def normalize(value):
    if isinstance(value, str):
        return " ".join(value.lower().split())
    if isinstance(value, list):
        return sorted(normalize(v) for v in value)
    return value


def load_dataset(path: str | Path) -> list[dict]:
    """JSONL: one labelled email per line."""
    return [json.loads(line) for line in Path(path).read_text(encoding="utf-8").splitlines() if line.strip()]


def evaluate(task: ClassificationTask, llm: LLMSettings, dataset: list[dict], client=None) -> dict:
    y_true, y_pred, rows = [], [], []
    field_hits, field_total = {}, {}
    for item in dataset:
        email = Email(subject=item["subject"], body=item["body"], sender=item.get("sender", ""),
                      attachment_names=item.get("attachment_names", []))
        result = classify_email(email, task, llm, client=client)
        y_true.append(item["label"])
        y_pred.append(result.label)
        if result.label == item["label"]:                 # fields are only compared when the label is right
            for name, expected in item.get("fields", {}).items():
                field_total[name] = field_total.get(name, 0) + 1
                ok = normalize(result.fields.get(name)) == normalize(expected)
                field_hits[name] = field_hits.get(name, 0) + int(ok)
        rows.append({"id": item.get("id"), "expected": item["label"], "predicted": result.label,
                     "fields": result.fields, "is_valid": result.is_valid, "duration_ms": result.duration_ms})

    labels = task.label_names
    return {
        "model": llm.model,
        "report": classification_report(y_true, y_pred, labels=labels, zero_division=0, output_dict=True),
        "report_text": classification_report(y_true, y_pred, labels=labels, zero_division=0),
        "confusion_matrix": confusion_matrix(y_true, y_pred, labels=labels).tolist(),
        "field_accuracy": {k: field_hits[k] / field_total[k] for k in field_total},
        "valid_rate": sum(r["is_valid"] for r in rows) / len(rows),
        "mean_duration_ms": sum(r["duration_ms"] for r in rows) / len(rows),
        "rows": rows,
    }
