from .models import Email, LLMSettings, ClassificationResult
from .task import ClassificationTask
from .classifier import classify_email
from .evaluate import evaluate

__all__ = ["Email", "LLMSettings", "ClassificationResult", "ClassificationTask", "classify_email", "evaluate"]
