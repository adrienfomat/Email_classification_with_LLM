from dataclasses import dataclass, field
from typing import Any


@dataclass
class Email:
    """An email in a source-independent format."""
    subject: str
    body: str
    sender: str = ""
    attachment_names: list[str] = field(default_factory=list)


@dataclass
class LLMSettings:
    """Which model to call and how."""
    model: str                                  # e.g. "qwen3.5:9b"
    host: str = "http://localhost:11434"        # Ollama server
    temperature: float = 0.0
    think: bool = False                         # reasoning mode off by default
    max_retries: int = 2                        # extra attempts if the output is invalid
    timeout_s: float = 120.0


@dataclass
class ClassificationResult:
    """Same structure for every project."""
    label: str
    fields: dict[str, Any]
    is_valid: bool
    model: str
    duration_ms: int
    attempts: int
    error: str | None = None
