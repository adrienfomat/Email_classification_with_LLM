from email import policy
from email.parser import BytesParser
from pathlib import Path

from .models import Email


def email_from_eml(path: str | Path) -> Email:
    """Read a .eml file (as exported by most mail clients) into the standard Email format."""
    msg = BytesParser(policy=policy.default).parsebytes(Path(path).read_bytes())
    body_part = msg.get_body(preferencelist=("plain", "html"))
    body = body_part.get_content() if body_part else ""
    attachments = [part.get_filename() for part in msg.iter_attachments() if part.get_filename()]
    return Email(subject=msg.get("subject", ""), body=body, sender=msg.get("from", ""),
                 attachment_names=attachments)
