from typing import TypedDict

from langgraph.graph import END, START, StateGraph

from emailclf import ClassificationTask, Email, LLMSettings, classify_email

TASK = ClassificationTask.from_yaml("configs/access_requests.yaml")
LLM = LLMSettings(model="qwen3.5:9b")


class State(TypedDict, total=False):
    email: Email
    label: str
    fields: dict
    is_valid: bool


def classify_node(state: State) -> dict:
    result = classify_email(state["email"], TASK, LLM)
    return {"label": result.label, "fields": result.fields, "is_valid": result.is_valid}


def route(state: State) -> str:
    if not state["is_valid"]:
        return "manual_review"
    return "check_attachments" if state["label"] == "access_request" else "out_of_scope"


def check_attachments(state: State) -> dict:
    return {}          # step 1 continues here (plain code, no LLM)


def manual_review(state: State) -> dict:
    return {}


def out_of_scope(state: State) -> dict:
    return {}


graph = StateGraph(State)
graph.add_node("classify_email", classify_node)
graph.add_node("check_attachments", check_attachments)
graph.add_node("manual_review", manual_review)
graph.add_node("out_of_scope", out_of_scope)
graph.add_edge(START, "classify_email")
graph.add_conditional_edges("classify_email", route, ["check_attachments", "manual_review", "out_of_scope"])
for node in ("check_attachments", "manual_review", "out_of_scope"):
    graph.add_edge(node, END)
app = graph.compile()

if __name__ == "__main__":
    print(app.invoke({"email": Email(subject="Accès Julie Martin",
                                     body="Merci d'ouvrir l'accès de Julie Martin. Concession A.",
                                     attachment_names=["attestation.pdf", "acces.xlsx"])}))
