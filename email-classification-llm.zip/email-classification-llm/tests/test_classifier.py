"""Tests without any LLM: a fake client returns prepared answers."""
import json
from types import SimpleNamespace
from pathlib import Path

from emailclf import ClassificationTask, Email, LLMSettings, classify_email, evaluate
from emailclf.evaluate import load_dataset

ROOT = Path(__file__).resolve().parents[1]
TASK = ClassificationTask.from_yaml(ROOT / "configs/access_requests.yaml")
LLM = LLMSettings(model="fake-model", max_retries=1)


class FakeClient:
    def __init__(self, answers):
        self.answers = list(answers)
        self.calls = []

    def chat(self, **kwargs):
        self.calls.append(kwargs)
        return SimpleNamespace(message=SimpleNamespace(content=self.answers.pop(0)))


def test_valid_answer_keeps_only_fields_of_label():
    answer = json.dumps({"label": "access_request",
                         "fields": {"request_type": "new", "company": "Concession A", "users": ["Julie Martin"]}})
    client = FakeClient([answer])
    result = classify_email(Email("Accès", "Merci d'ouvrir l'accès de Julie Martin"), TASK, LLM, client=client)
    assert result.is_valid and result.label == "access_request"
    assert result.fields == {"request_type": "new", "company": "Concession A", "users": ["Julie Martin"]}
    assert client.calls[0]["think"] is False
    assert client.calls[0]["options"] == {"temperature": 0.0}


def test_invalid_label_is_retried_then_falls_back():
    bad = json.dumps({"label": "spam", "fields": {}})
    result = classify_email(Email("x", "y"), TASK, LLM, client=FakeClient([bad, "not json"]))
    assert not result.is_valid and result.label == "other" and result.attempts == 2


def test_second_attempt_can_succeed():
    good = json.dumps({"label": "other", "fields": {}})
    result = classify_email(Email("x", "y"), TASK, LLM, client=FakeClient(["{oops", good]))
    assert result.is_valid and result.attempts == 2


def test_evaluate_on_sample_dataset():
    dataset = load_dataset(ROOT / "data/test_set_sample.jsonl")
    answers = [json.dumps({"label": d["label"], "fields": d["fields"]}) for d in dataset]
    answers[2] = json.dumps({"label": "access_request", "fields": {}})       # one deliberate mistake
    report = evaluate(TASK, LLM, dataset, client=FakeClient(answers))
    assert report["valid_rate"] == 1.0
    assert report["confusion_matrix"] == [[3, 0], [1, 2]]
    assert report["field_accuracy"]["company"] == 1.0


def test_second_config_loads():
    task = ClassificationTask.from_yaml(ROOT / "configs/invoices.yaml")
    schema = task.output_model().model_json_schema()
    assert set(task.label_names) == {"invoice", "payment_reminder", "other"}
    assert "amount" in json.dumps(schema)
